/**
 * 
 */
package com.cts.course.service;

/**
 * @author jayaramu.v
 *
 */
public interface UserProcessService {
	public void readUserDetails();
}
