/**
 * 
 */
package com.cts.course.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.web.multipart.MultipartFile;

import com.cts.course.data.AdvanceFilterDataImport;
import com.cts.course.data.BasicFilterDataImport;
import com.cts.course.data.CatalogueData;
import com.cts.course.data.ColumnNameData;
import com.cts.course.data.CourseListExportData;
import com.cts.course.globals.CustomeExceptionHandler;
import com.cts.course.model.Catalogue;

/**
 * @author Jayaramu Vellingiri
 *
 */
public interface CatalougeServiceI {	

	public String validateInputExcel(MultipartFile uploadFile) throws Exception;
	
	public Map<Integer, String> validateReadHeader(Sheet catalogueSheet) throws CustomeExceptionHandler;

	public List<HashMap<String, String>> readInputExcel(MultipartFile uploadFile) throws Exception;
	
	public String readInputExcelNInsertRecord(MultipartFile uploadFile) throws Exception;
	
	public CourseListExportData readAllCourseCatalogue(Integer pageNumber, Integer rowLimit) throws Exception;

	public CourseListExportData readCourseCatalogueByBasicFilter(BasicFilterDataImport filterImport) throws Exception;

	public CourseListExportData readCourseCatalogueByAdvanceFilterCatalogue(List<AdvanceFilterDataImport> advanceFilterDataImportList) throws Exception;
	
	public List<ColumnNameData> readColumnNames() throws Exception;
	
	public ByteArrayInputStream downloadCatalogueDetails(List<CatalogueData> catalogueDataList) throws IOException;
	
	public List<CatalogueData> loadCatalogueIntoData(List<Catalogue> catalougeList) throws Exception;
}
