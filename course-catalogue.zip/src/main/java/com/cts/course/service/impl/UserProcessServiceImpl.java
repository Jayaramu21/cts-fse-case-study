/**
 * 
 */
package com.cts.course.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.course.dao.UserDAOI;
import com.cts.course.service.UserProcessService;

/**
 * @author jayaramu.v
 *
 */
@Service
@Transactional
public class UserProcessServiceImpl implements UserProcessService {

	@Autowired
	private UserDAOI userDao;
	
	@Override
	public void readUserDetails() {
		userDao.readUserDetails();
		
	}

}
