/**
 * 
 */
package com.cts.course.service.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.lang.invoke.MethodHandles;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.cts.course.dao.CourseCatalogueDAOI;
import com.cts.course.data.AdvanceFilterDataImport;
import com.cts.course.data.BasicFilterDataImport;
import com.cts.course.data.CatalogueData;
import com.cts.course.data.ColumnNameData;
import com.cts.course.data.CourseListExportData;
import com.cts.course.data.ExpertiseData;
import com.cts.course.data.LanguageData;
import com.cts.course.data.MediaTypeData;
import com.cts.course.data.OwnerData;
import com.cts.course.data.SkillData;
import com.cts.course.data.TrainingOrganizationData;
import com.cts.course.globals.CustomeExceptionHandler;
import com.cts.course.globals.ExcelColumnHeaderEnum;
import com.cts.course.model.Catalogue;
import com.cts.course.model.ColumnName;
import com.cts.course.model.Expertise;
import com.cts.course.model.Language;
import com.cts.course.model.MediaType;
import com.cts.course.model.Owner;
import com.cts.course.model.Skill;
import com.cts.course.model.TrainingOrganization;
import com.cts.course.service.CatalougeServiceI;

/**
 * @author Jayaramu Vellingiri
 *
 */
@Service("catalougeService")
@Transactional
public class CatalougeService implements CatalougeServiceI {

	@Autowired
	CourseCatalogueDAOI courseCatalogueDAO;

	private static final Logger LOGGER = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

	@Override
	public String validateInputExcel(MultipartFile uploadFile) {
		Workbook catalogueWorkbook = null;
		String validationStatus = "Success";
		try {
			// Create Workbook instance holding reference to .xlsx file
			catalogueWorkbook = new XSSFWorkbook(uploadFile.getInputStream());
			// Get first/desired sheet from the workbook
			Sheet catalogueSheet = catalogueWorkbook.getSheetAt(0);
			int lastRowNum = catalogueSheet.getLastRowNum();
			Map<Integer, String> headerMap = validateReadHeader(catalogueSheet);

			for (int rowNo = 1; rowNo <= lastRowNum; rowNo++) {
				Row row = catalogueSheet.getRow(rowNo);
				for (int cellNo = 0; cellNo < row.getLastCellNum(); cellNo++) {
					String cellValue = "";
					CellType cell = row.getCell(cellNo).getCellType();

					switch (cell) {
					case NUMERIC:
						cellValue = String.valueOf(row.getCell(cellNo).getNumericCellValue());
						break;
					case STRING:
						cellValue = row.getCell(cellNo).getStringCellValue();
						break;
					default:
						cellValue = row.getCell(cellNo).getStringCellValue();
						break;
					}

					String header = headerMap.get(cellNo);
					if (StringUtils.isBlank(cellValue)
							&& (header.equalsIgnoreCase(ExcelColumnHeaderEnum.COURSENAME.getHeaderName())
									|| header.equalsIgnoreCase(ExcelColumnHeaderEnum.ACTIVITYSTATUS.getHeaderName())
									|| header.equalsIgnoreCase(ExcelColumnHeaderEnum.OWNER.getHeaderName())
									|| header.equalsIgnoreCase(ExcelColumnHeaderEnum.LANGUAGE.getHeaderName())
									|| header.equalsIgnoreCase(ExcelColumnHeaderEnum.LICENCENEED.getHeaderName())
									|| header.equalsIgnoreCase(ExcelColumnHeaderEnum.SKILL.getHeaderName())
									|| header.equalsIgnoreCase(ExcelColumnHeaderEnum.PROFICIENCY.getHeaderName())
									|| header.equalsIgnoreCase(ExcelColumnHeaderEnum.CODE.getHeaderName()))) {
						validationStatus = "Column: " + header
								+ " value should not be empty.";
						throw new CustomeExceptionHandler("Validation error -> validateInputExcel {}: Column " + header
								+ " value should not be empty.");
					}
				}
			}
		} catch (CustomeExceptionHandler cusEx) {
			validationStatus = cusEx.toString();
			LOGGER.error("Custome exception in CatalougeService -> validateInputExcel: {}" + cusEx.toString());
		} catch (IOException e) {
			validationStatus = "Error while verify data. Please check log for more details.";
			LOGGER.error(validationStatus);
		} finally {
			if (catalogueWorkbook != null) {
				try {
					catalogueWorkbook.close();
				} catch (IOException e) {
					validationStatus = "Error while verify data. Please check log for more details.";
					LOGGER.error("Error in CatalougeService -> validateInputExcel finally block: {}", e.getMessage());
				}
			}
		}
		return validationStatus;

	}

	@Override
	public Map<Integer, String> validateReadHeader(Sheet catalogueSheet) throws CustomeExceptionHandler {

		Map<Integer, String> headerMap = new HashMap<Integer, String>();

		String courseName = ExcelColumnHeaderEnum.COURSENAME.getHeaderName();
		String description = ExcelColumnHeaderEnum.DESCRIPTION.getHeaderName();
		String duration = ExcelColumnHeaderEnum.DURATION.getHeaderName();
		String activeStatus = ExcelColumnHeaderEnum.ACTIVITYSTATUS.getHeaderName();
		String code = ExcelColumnHeaderEnum.CODE.getHeaderName();
		String trainingOraganization = ExcelColumnHeaderEnum.TRAININGORGANIZATION.getHeaderName();
		String owner = ExcelColumnHeaderEnum.OWNER.getHeaderName();
		String language = ExcelColumnHeaderEnum.LANGUAGE.getHeaderName();
		String mediaType = ExcelColumnHeaderEnum.MEDIATYPE.getHeaderName();
		String prerequisites = ExcelColumnHeaderEnum.PREREQUISITES.getHeaderName();
		String licenceNeed = ExcelColumnHeaderEnum.LICENCENEED.getHeaderName();
		String notes = ExcelColumnHeaderEnum.NOTES.getHeaderName();
		String skill = ExcelColumnHeaderEnum.SKILL.getHeaderName();
		String expertise = ExcelColumnHeaderEnum.EXPERTISE.getHeaderName();
		String proficiency = ExcelColumnHeaderEnum.PROFICIENCY.getHeaderName();
		
		int lastRowNum = catalogueSheet.getLastRowNum();
		if (lastRowNum > 0) {
			Row headerRow = catalogueSheet.getRow(0);
			for (int cellNo = 0; cellNo < headerRow.getLastCellNum(); cellNo++) {
				String cellValue = "";
				CellType cell = headerRow.getCell(cellNo).getCellType();
				switch (cell) {
				case NUMERIC:
					cellValue = String.valueOf(headerRow.getCell(cellNo).getNumericCellValue());
					break;
				case STRING:
					cellValue = headerRow.getCell(cellNo).getStringCellValue();
					break;
				default:
					cellValue = headerRow.getCell(cellNo).getStringCellValue();
					break;
				}

				cellValue = cellValue.trim();
				if (cellValue.equalsIgnoreCase(courseName) || cellValue.equalsIgnoreCase(description)
						|| cellValue.equalsIgnoreCase(duration) || cellValue.equalsIgnoreCase(activeStatus)
						|| cellValue.equalsIgnoreCase(code) || cellValue.equalsIgnoreCase(trainingOraganization)
						|| cellValue.equalsIgnoreCase(owner) || cellValue.equalsIgnoreCase(language)
						|| cellValue.equalsIgnoreCase(mediaType) || cellValue.equalsIgnoreCase(prerequisites)
						|| cellValue.equalsIgnoreCase(licenceNeed) || cellValue.equalsIgnoreCase(notes)
						|| cellValue.equalsIgnoreCase(skill) || cellValue.equalsIgnoreCase(expertise) || cellValue.equalsIgnoreCase(proficiency)) {
					headerMap.put(cellNo, cellValue);
				} else {
					throw new CustomeExceptionHandler(
							"Please verify excel column heder: " + cellValue);
				}
			}
		}
		return headerMap;
	}

	@Override
	public List<HashMap<String, String>> readInputExcel(MultipartFile uploadFile) throws Exception {
		String validationStatus = validateInputExcel(uploadFile);
		List<HashMap<String, String>> catalogueList = new ArrayList<HashMap<String, String>>();
		if (validationStatus.equalsIgnoreCase("Success")) {
			Workbook catalogueWorkbook = null;
			try {
				// Create Workbook instance holding reference to .xlsx file
				catalogueWorkbook = new XSSFWorkbook(uploadFile.getInputStream());
				// Get first/desired sheet from the workbook
				Sheet catalogueSheet = catalogueWorkbook.getSheetAt(0);
				Map<Integer, String> headerMap = validateReadHeader(catalogueSheet);
				int lastRowNum = catalogueSheet.getLastRowNum();
				for (int rowNo = 1; rowNo <= lastRowNum; rowNo++) {
					Row row = catalogueSheet.getRow(rowNo);
					HashMap<String, String> catalogueMap = new HashMap<String, String>();
					for (int cellNo = 0; cellNo < row.getLastCellNum(); cellNo++) {
						String cellValue = "";
						CellType cell = row.getCell(cellNo).getCellType();
						switch (cell) {
						case NUMERIC:
							cellValue = String.valueOf(row.getCell(cellNo).getNumericCellValue());
							break;
						case STRING:
							cellValue = row.getCell(cellNo).getStringCellValue();
							break;
						default:
							cellValue = row.getCell(cellNo).getStringCellValue();
							break;
						}

						cellValue = cellValue.trim();
						String header = headerMap.get(cellNo);
						catalogueMap.put(header, cellValue.replaceAll(".0", ""));
					}
					catalogueList.add(catalogueMap);
				}
			} catch (IOException e) {
			} catch (CustomeExceptionHandler e) {
			}
		} else {
			return null;
		}
		return catalogueList;
	}

	@Override
	public String readInputExcelNInsertRecord(MultipartFile uploadFile) {
		String status = "Success";
		try {
			List<HashMap<String, String>> excelCatalogueList = readInputExcel(uploadFile);
			System.out.println("excelCatalogueList: " + excelCatalogueList.toString());
			List<Language> languageList = courseCatalogueDAO.getLanguageList();
			List<MediaType> mediaTypeList = courseCatalogueDAO.getMediaTypeList();
			List<Owner> ownerList = courseCatalogueDAO.getOwnerList();
			List<Skill> skillList = courseCatalogueDAO.getSkillList();
			List<Expertise> expertiseList = courseCatalogueDAO.geExpertiseList();
			List<TrainingOrganization> trainingOrganizationList = courseCatalogueDAO.getTrainingOrganizationList();
			List<Catalogue> catalogueList = new ArrayList<>();

			for (HashMap<String, String> catalogueMap : excelCatalogueList) {

				String languageStr = catalogueMap.get(ExcelColumnHeaderEnum.LANGUAGE.getHeaderName()).trim();
				String mediaTypeStr = catalogueMap.get(ExcelColumnHeaderEnum.MEDIATYPE.getHeaderName()).trim();
				String ownerStr = catalogueMap.get(ExcelColumnHeaderEnum.OWNER.getHeaderName()).trim();
				String skillStr = catalogueMap.get(ExcelColumnHeaderEnum.SKILL.getHeaderName()).trim();
				String trainingOrgStr = catalogueMap.get(ExcelColumnHeaderEnum.TRAININGORGANIZATION.getHeaderName()).trim();
				String expertiseStr = catalogueMap.get(ExcelColumnHeaderEnum.EXPERTISE.getHeaderName()).trim();

				Language language = languageList.stream()
						.filter(languageOb -> languageStr.equalsIgnoreCase(languageOb.getLanguage().trim())).findAny()
						.orElse(null);
				MediaType mediaType = mediaTypeList.stream()
						.filter(mediaTypeOb -> mediaTypeStr.equalsIgnoreCase(mediaTypeOb.getType().trim())).findAny()
						.orElse(null);
				Owner owner = ownerList.stream().filter(ownerOb -> ownerStr.equalsIgnoreCase(ownerOb.getOwner().trim()))
						.findAny().orElse(null);
				Skill skill = skillList.stream().filter(skillOb -> skillStr.equalsIgnoreCase(skillOb.getSkill().trim()))
						.findAny().orElse(null);
				TrainingOrganization trainingOrganization = trainingOrganizationList.stream()
						.filter(trainingOrganizationOb -> trainingOrgStr
								.equalsIgnoreCase(trainingOrganizationOb.getOrganization().trim()))
						.findAny().orElse(null);
				Expertise expertise = expertiseList.stream()
						.filter(expertiseOb -> expertiseStr.equalsIgnoreCase(expertiseOb.getExpertise().trim()))
						.findAny().orElse(null);

				if (language == null) {
					language = new Language();
					language.setLanguage(languageStr);
					courseCatalogueDAO.saveLanuage(language);
				}
				if (expertise == null) {
					expertise = new Expertise();
					expertise.setExpertise(expertiseStr);
					courseCatalogueDAO.saveExpertise(expertise);
				}
				if (mediaType == null) {
					mediaType = new MediaType();
					mediaType.setType(mediaTypeStr);
					courseCatalogueDAO.saveMediaType(mediaType);
				}
				if (owner == null) {
					owner = new Owner();
					owner.setOwner(ownerStr);
					courseCatalogueDAO.saveOwner(owner);
				}
				if (skill == null) {
					skill = new Skill();
					skill.setSkill(skillStr);
					courseCatalogueDAO.saveSkill(skill);
				}
				if (trainingOrganization == null) {
					trainingOrganization = new TrainingOrganization();
					trainingOrganization.setOrganization(trainingOrgStr);
					courseCatalogueDAO.saveTrainingOrg(trainingOrganization);
				}

				Catalogue catalouge = new Catalogue();
				String activeStatus = catalogueMap.get(ExcelColumnHeaderEnum.ACTIVITYSTATUS.getHeaderName()).trim();
				catalouge.setActiveStatus(activeStatus.trim().equalsIgnoreCase("Active") ? 'A' : 'N');
				catalouge.setCreateDate(new Date(new java.util.Date().getTime()));
				catalouge.setCode(catalogueMap.get(ExcelColumnHeaderEnum.CODE.getHeaderName()).trim());
				catalouge.setDescription(catalogueMap.get(ExcelColumnHeaderEnum.DESCRIPTION.getHeaderName()).trim());
				catalouge.setDuration(catalogueMap.get(ExcelColumnHeaderEnum.DURATION.getHeaderName()).trim());
				catalouge.setProficiencyLevel(Integer.valueOf(catalogueMap.get(ExcelColumnHeaderEnum.PROFICIENCY.getHeaderName()).trim()));
				catalouge.setExpertise(expertise);
				catalouge.setLanguage(language);
				catalouge.setLicenceInd(
						catalogueMap.get(ExcelColumnHeaderEnum.LICENCENEED.getHeaderName()).trim().equalsIgnoreCase("Yes") ? true
								: false);
				catalouge.setMediaType(mediaType);
				catalouge.setName(catalogueMap.get(ExcelColumnHeaderEnum.COURSENAME.getHeaderName()).trim());
				catalouge.setNotes(catalogueMap.get(ExcelColumnHeaderEnum.NOTES.getHeaderName().trim()));
				catalouge.setOwner(owner);
				catalouge
						.setPrerequisites(catalogueMap.get(ExcelColumnHeaderEnum.PREREQUISITES.getHeaderName().trim()));
				catalouge.setSkill(skill);
				catalouge.setTrainingOrganization(trainingOrganization);
				
				
				catalogueList.add(catalouge);
			}

			if (!catalogueList.isEmpty()) {
				courseCatalogueDAO.saveCourseCatalogue(catalogueList);
			}
		} catch (Exception e) {
			status = "Error occured : " + e.getMessage();
			LOGGER.error("Error in CatalougeService -> readInputExcelNInsertRecord: {}", e.getMessage());
		}
		return status;
	}

	@Override
	public CourseListExportData readAllCourseCatalogue(Integer pageNumber, Integer rowLimit) {
		CourseListExportData courseListExportData = new CourseListExportData();
		try {			
			Integer offSet = (pageNumber -1) * rowLimit;			
			List<Catalogue> catalogueList = courseCatalogueDAO.getCatalougeList(pageNumber, offSet, rowLimit);
			courseListExportData.setData(loadCatalogueIntoData(catalogueList));
		} catch (Exception e) {
			LOGGER.error("Error in CatalougeService -> readAllCourseCatalogue: {}", e.getMessage());
		}
		return courseListExportData;
	}

	@Override
	public CourseListExportData readCourseCatalogueByBasicFilter(BasicFilterDataImport filterImport) {
		try {
			List<Catalogue> catalogueList = courseCatalogueDAO.getCatalogueByBasicFilter(filterImport);
			CourseListExportData courseListExportData = new CourseListExportData();
			courseListExportData.setData(loadCatalogueIntoData(catalogueList));
			return courseListExportData;
		} catch (Exception e) {
			LOGGER.error("Error in CatalougeService -> readCourseCatalogueByBasicFilter: {}", e.getMessage());
		}
		return new CourseListExportData();
	}

	@Override
	public CourseListExportData readCourseCatalogueByAdvanceFilterCatalogue(
			List<AdvanceFilterDataImport> advanceFilterDataImportList) {
		try {
			List<Catalogue> catalogueList = courseCatalogueDAO.getCatalogueByAdvanceFilter(advanceFilterDataImportList);
			CourseListExportData courseListExportData = new CourseListExportData();
			courseListExportData.setData(loadCatalogueIntoData(catalogueList));
			System.out.println("Catalog: "+ courseListExportData.getData().get(0).toString());
			return courseListExportData;
		} catch (Exception e) {
			LOGGER.error("Error in CatalougeService -> readCourseCatalogueByAdvanceFilterCatalogue: {}", e.getMessage());
		}
		return new CourseListExportData();
	}

	@Override
	public List<ColumnNameData> readColumnNames() {
		try {
			List<ColumnName> columnNameList = courseCatalogueDAO.getColumnName();
			List<ColumnNameData> columnNameDataList = new ArrayList<>();
			for (ColumnName columnName : columnNameList) {
				ColumnNameData columnNameData = new ColumnNameData();
				columnNameData.setName(columnName.getName());
				columnNameData.setColumnAliasName(columnName.getColumnAliasName());
				columnNameDataList.add(columnNameData);
			}
			return columnNameDataList;
		} catch (Exception e) {
			LOGGER.error("Error in CatalougeService -> readColumnNames: {}", e.getMessage());
		}
		return new ArrayList<>();
	}

	@Override
	public List<CatalogueData> loadCatalogueIntoData(List<Catalogue> catalougeList) {
		List<CatalogueData> catalougeDataList = new ArrayList<>();
		for (Catalogue catalouge : catalougeList) {
			CatalogueData catalougeData = new CatalogueData();
			TrainingOrganizationData trainingOrganizationData = new TrainingOrganizationData();
			OwnerData ownerData = new OwnerData();
			LanguageData languageData = new LanguageData();
			MediaTypeData mediaTypeData = new MediaTypeData();
			ExpertiseData expertiseData = new ExpertiseData();
			SkillData skillData = new SkillData();

			catalougeData.setActiveStatus(catalouge.getActiveStatus());
			catalougeData.setCreateDate(catalouge.getCreateDate());
			catalougeData.setDescription(catalouge.getDescription().trim());
			catalougeData.setDuration(catalouge.getDuration().trim());
			catalougeData.setLicenceInd(catalouge.isLicenceInd());
			catalougeData.setName(catalouge.getName().trim());
			catalougeData.setNotes(catalouge.getNotes().trim());
			catalougeData.setPrerequisites(catalouge.getPrerequisites().trim());
			catalougeData.setProficiencyLevel(catalouge.getProficiencyLevel());
			catalougeData.setCode(catalouge.getCode());

			trainingOrganizationData.setOrganization(catalouge.getTrainingOrganization().getOrganization().trim());
			ownerData.setOwner(catalouge.getOwner().getOwner().trim());
			languageData.setLanguage(catalouge.getLanguage().getLanguage().trim());
			mediaTypeData.setType(catalouge.getMediaType().getType().trim());
			expertiseData.setExpertise(catalouge.getExpertise().getExpertise().trim());
			skillData.setSkill(catalouge.getSkill().getSkill().trim());
			
			catalougeData.setTrainingOrganization(trainingOrganizationData);
			catalougeData.setOwner(ownerData);
			catalougeData.setLanguage(languageData);
			catalougeData.setMediaType(mediaTypeData);
			catalougeData.setExpertise(expertiseData);
			catalougeData.setSkill(skillData);			
			catalougeDataList.add(catalougeData);
		}
		Collections.sort(catalougeDataList);
		return catalougeDataList;
	}
	
	@Override
	public ByteArrayInputStream downloadCatalogueDetails(List<CatalogueData> catalogueDataList)throws IOException {

		try(Workbook courseWorkBook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();){
			Sheet excelSheet = courseWorkBook.createSheet();
			int rowNum = 0;
			Row row = excelSheet.createRow(rowNum++);
			row.createCell(0).setCellValue(ExcelColumnHeaderEnum.CODE.getHeaderName());
			row.createCell(1).setCellValue(ExcelColumnHeaderEnum.COURSENAME.getHeaderName());
			row.createCell(2).setCellValue(ExcelColumnHeaderEnum.DESCRIPTION.getHeaderName());
			row.createCell(3).setCellValue(ExcelColumnHeaderEnum.DURATION.getHeaderName());
			row.createCell(4).setCellValue(ExcelColumnHeaderEnum.ACTIVITYSTATUS.getHeaderName());
			row.createCell(5).setCellValue(ExcelColumnHeaderEnum.TRAININGORGANIZATION.getHeaderName());
			row.createCell(6).setCellValue(ExcelColumnHeaderEnum.OWNER.getHeaderName());
			row.createCell(7).setCellValue(ExcelColumnHeaderEnum.LANGUAGE.getHeaderName());
			row.createCell(8).setCellValue(ExcelColumnHeaderEnum.MEDIATYPE.getHeaderName());
			row.createCell(9).setCellValue(ExcelColumnHeaderEnum.EXPERTISE.getHeaderName());
			row.createCell(10).setCellValue(ExcelColumnHeaderEnum.PREREQUISITES.getHeaderName());
			row.createCell(11).setCellValue(ExcelColumnHeaderEnum.LICENCENEED.getHeaderName());
			row.createCell(12).setCellValue(ExcelColumnHeaderEnum.NOTES.getHeaderName());
			row.createCell(13).setCellValue(ExcelColumnHeaderEnum.SKILL.getHeaderName());
			row.createCell(14).setCellValue(ExcelColumnHeaderEnum.PROFICIENCY.getHeaderName());
			
			for(CatalogueData catalogueData : catalogueDataList) {
				int cellNo = 0;
				row = excelSheet.createRow(rowNum++);
				row.createCell(cellNo++).setCellValue(catalogueData.getCode());
				row.createCell(cellNo++).setCellValue(catalogueData.getName());
				row.createCell(cellNo++).setCellValue(catalogueData.getDescription());
				row.createCell(cellNo++).setCellValue(catalogueData.getDuration());
				row.createCell(cellNo++).setCellValue(catalogueData.getActiveStatus());
				row.createCell(cellNo++).setCellValue(catalogueData.getTrainingOrganization() == null ? "" : catalogueData.getTrainingOrganization().getOrganization());
				row.createCell(++cellNo).setCellValue(catalogueData.getOwner() == null ? "" : catalogueData.getOwner().getOwner());
				row.createCell(cellNo++).setCellValue(catalogueData.getLanguage() == null ? "" : catalogueData.getLanguage().getLanguage());
				row.createCell(++cellNo).setCellValue(catalogueData.getMediaType() == null ? "" : catalogueData.getMediaType().getType());
				row.createCell(++cellNo).setCellValue(catalogueData.getExpertise() == null ? "" : catalogueData.getExpertise().getExpertise());
				row.createCell(cellNo++).setCellValue(catalogueData.getPrerequisites());
				row.createCell(cellNo++).setCellValue(catalogueData.isLicenceInd());
				row.createCell(cellNo++).setCellValue(catalogueData.getNotes());
				row.createCell(cellNo++).setCellValue(catalogueData.getSkill() == null ? "" : catalogueData.getSkill().getSkill());
				row.createCell(cellNo++).setCellValue(catalogueData.getProficiencyLevel());
			}
			courseWorkBook.write(out);
			return new ByteArrayInputStream(out.toByteArray());
		}
	}

}
