/**
 * 
 */
package com.cts.course.data;

import java.io.Serializable;

/**
 * @author Jayaramu Vellingiri
 *
 */
public class ExpertiseData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7657151472639654929L;
	private int id;
	private String expertise;
	
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the expertise
	 */
	public String getExpertise() {
		return expertise;
	}
	/**
	 * @param expertise the expertise to set
	 */
	public void setExpertise(String expertise) {
		this.expertise = expertise;
	}
	@Override
	public String toString() {
		return String.format("ExpertiseData [id=%s, expertise=%s]", id, expertise);
	}
	
	
}
