/**
 * 
 */
package com.cts.course.data;

import java.io.Serializable;

/**
 * @author Jayaramu Vellingiri
 *
 */
public class LanguageData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 924714083358566717L;
	private int id;
	private String language;
	
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the language
	 */
	public String getLanguage() {
		return language;
	}
	/**
	 * @param language the language to set
	 */
	public void setLanguage(String language) {
		this.language = language;
	}
	@Override
	public String toString() {
		return String.format("LanguageData [id=%s, language=%s]", id, language);
	}
	
}
