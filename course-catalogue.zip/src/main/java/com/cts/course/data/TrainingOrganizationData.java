/**
 * 
 */
package com.cts.course.data;

import java.io.Serializable;

/**
 * @author Jayaramu Vellingiri
 *
 */
public class TrainingOrganizationData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2387738698829145990L;
	private int id;
	private String organization;
	
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the organization
	 */
	public String getOrganization() {
		return organization;
	}
	/**
	 * @param organization the organization to set
	 */
	public void setOrganization(String organization) {
		this.organization = organization;
	}
	@Override
	public String toString() {
		return String.format("TrainingOrganizationData [id=%s, organization=%s]", id, organization);
	}
	
}
