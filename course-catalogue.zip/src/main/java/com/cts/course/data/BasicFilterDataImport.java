/**
 * 
 */
package com.cts.course.data;

import java.io.Serializable;

/**
 * @author Jayaramu Vellingiri
 *
 */
public class BasicFilterDataImport implements Serializable {

	private static final long serialVersionUID = -260601138893256203L;
	
	private String courseName;
	private String skill;
	private Integer proficiencyLevel;
	private String courseNameOperator;
	private String skillOperator;
	private String proficiencyLevelOperator;
	
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getSkill() {
		return skill;
	}
	public void setSkill(String skill) {
		this.skill = skill;
	}
	public Integer getProficiencyLevel() {
		return proficiencyLevel;
	}
	public void setProficiencyLevel(Integer proficiencyLevel) {
		this.proficiencyLevel = proficiencyLevel;
	}
	
	public String getCourseNameOperator() {
		return courseNameOperator;
	}
	public void setCourseNameOperator(String courseNameOperator) {
		this.courseNameOperator = courseNameOperator;
	}
	public String getSkillOperator() {
		return skillOperator;
	}
	public void setSkillOperator(String skillOperator) {
		this.skillOperator = skillOperator;
	}
	public String getProficiencyLevelOperator() {
		return proficiencyLevelOperator;
	}
	public void setProficiencyLevelOperator(String proficiencyLevelOperator) {
		this.proficiencyLevelOperator = proficiencyLevelOperator;
	}
	
	@Override
	public String toString() {
		return String.format(
				"BasicFilterDataImport [courseName=%s, skill=%s, proficiencyLevel=%s, courseNameOperator=%s, skillOperator=%s, proficiencyLevelOperator=%s]",
				courseName, skill, proficiencyLevel, courseNameOperator, skillOperator, proficiencyLevelOperator);
	}
}
