/**
 * 
 */
package com.cts.course.data;

import java.io.Serializable;

/**
 * @author Jayaramu Vellingiri
 *
 */
public class SkillData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5801747456342371540L;
	private int id;
	private String skill;
	
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the skill
	 */
	public String getSkill() {
		return skill;
	}
	/**
	 * @param skill the skill to set
	 */
	public void setSkill(String skill) {
		this.skill = skill;
	}
	@Override
	public String toString() {
		return String.format("SkillData [id=%s, skill=%s]", id, skill);
	}
}
