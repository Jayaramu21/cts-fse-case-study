/**
 * 
 */
package com.cts.course.data;

import java.io.Serializable;

/**
 * @author Jayaramu Vellingiri
 *
 */
public class OwnerData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7943483371844362769L;
	private int id;
	private String owner;
	
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the owner
	 */
	public String getOwner() {
		return owner;
	}
	/**
	 * @param owner the owner to set
	 */
	public void setOwner(String owner) {
		this.owner = owner;
	}
	@Override
	public String toString() {
		return String.format("OwnerData [id=%s, owner=%s]", id, owner);
	}
}
