/**
 * 
 */
package com.cts.course.data;

import java.io.Serializable;

/**
 * @author Jayaramu Vellingiri
 *
 */
public class AdvanceFilterDataImport implements Serializable {

	private static final long serialVersionUID = -6479468503872218310L;

	private String columnName;
	private String operator;
	private String value;

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return String.format("AdvanceFilterDataImport [columnName=%s, operator=%s, value=%s]", columnName, operator,
				value);
	}

}
