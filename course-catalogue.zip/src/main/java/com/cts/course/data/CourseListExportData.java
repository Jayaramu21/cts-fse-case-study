/**
 * 
 */
package com.cts.course.data;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Jayaramu Vellingiri
 *
 */
public class CourseListExportData {

	List<CatalogueData>  data = new ArrayList<CatalogueData>();

	public List<CatalogueData> getData() {
		return data;
	}

	public void setData(List<CatalogueData> data) {
		this.data = data;
	}
	
}
