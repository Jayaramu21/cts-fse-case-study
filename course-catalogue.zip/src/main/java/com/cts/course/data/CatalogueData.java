/**
 * 
 */
package com.cts.course.data;

import java.io.Serializable;
import java.sql.Date;

/**
 * @author Jayaramu Vellingiri
 *
 */
public class CatalogueData implements Serializable, Comparable< CatalogueData > {

	/**
	 * 
	 */
	private static final long serialVersionUID = -783250033747969779L;
	
	private int id;
	private String name;
	private String code;
	private String description;
	private String duration;
	private String prerequisites;
	private String notes;
	private Date createDate;	
	private boolean licenceInd;
	private char activeStatus;
	private Integer proficiencyLevel;
	
	private TrainingOrganizationData trainingOrganization;
	private OwnerData owner;
	private LanguageData language;
	private MediaTypeData mediaType;
	private ExpertiseData expertise;
	private SkillData skill;
	
	
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the duration
	 */
	public String getDuration() {
		return duration;
	}
	/**
	 * @param duration the duration to set
	 */
	public void setDuration(String duration) {
		this.duration = duration;
	}
	/**
	 * @return the prerequisites
	 */
	public String getPrerequisites() {
		return prerequisites;
	}
	/**
	 * @param prerequisites the prerequisites to set
	 */
	public void setPrerequisites(String prerequisites) {
		this.prerequisites = prerequisites;
	}
	/**
	 * @return the notes
	 */
	public String getNotes() {
		return notes;
	}
	/**
	 * @param notes the notes to set
	 */
	public void setNotes(String notes) {
		this.notes = notes;
	}
	/**
	 * @return the createDate
	 */
	public Date getCreateDate() {
		return createDate;
	}
	/**
	 * @param createDate the createDate to set
	 */
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	/**
	 * @return the licenceInd
	 */
	public boolean isLicenceInd() {
		return licenceInd;
	}
	/**
	 * @param licenceInd the licenceInd to set
	 */
	public void setLicenceInd(boolean licenceInd) {
		this.licenceInd = licenceInd;
	}
	/**
	 * @return the trainingOrganization
	 */
	public TrainingOrganizationData getTrainingOrganization() {
		return trainingOrganization;
	}
	/**
	 * @param trainingOrganization the trainingOrganization to set
	 */
	public void setTrainingOrganization(TrainingOrganizationData trainingOrganization) {
		this.trainingOrganization = trainingOrganization;
	}
	/**
	 * @return the owner
	 */
	public OwnerData getOwner() {
		return owner;
	}
	/**
	 * @param owner the owner to set
	 */
	public void setOwner(OwnerData owner) {
		this.owner = owner;
	}
	/**
	 * @return the language
	 */
	public LanguageData getLanguage() {
		return language;
	}
	/**
	 * @param language the language to set
	 */
	public void setLanguage(LanguageData language) {
		this.language = language;
	}
	/**
	 * @return the mediaType
	 */
	public MediaTypeData getMediaType() {
		return mediaType;
	}
	/**
	 * @param mediaType the mediaType to set
	 */
	public void setMediaType(MediaTypeData mediaType) {
		this.mediaType = mediaType;
	}
	/**
	 * @return the expertise
	 */
	public ExpertiseData getExpertise() {
		return expertise;
	}
	/**
	 * @param expertise the expertise to set
	 */
	public void setExpertise(ExpertiseData expertise) {
		this.expertise = expertise;
	}
	/**
	 * @return the skill
	 */
	public SkillData getSkill() {
		return skill;
	}
	/**
	 * @param skill the skill to set
	 */
	public void setSkill(SkillData skill) {
		this.skill = skill;
	}
	
	public char getActiveStatus() {
		return activeStatus;
	}
	public void setActiveStatus(char activeStatus) {
		this.activeStatus = activeStatus;
	}
	public Integer getProficiencyLevel() {
		return proficiencyLevel;
	}
	public void setProficiencyLevel(Integer proficiencyLevel) {
		this.proficiencyLevel = proficiencyLevel;
	}
	@Override
	public String toString() {
		return String.format(
				"CatalogueData [id=%s, name=%s, description=%s, duration=%s, prerequisites=%s, notes=%s, createDate=%s, licenceInd=%s, activeStatus=%s, proficiencyLevel=%s, trainingOrganization=%s, owner=%s, language=%s, mediaType=%s, expertise=%s, skill=%s]",
				id, name, description, duration, prerequisites, notes, createDate, licenceInd, activeStatus,
				proficiencyLevel, trainingOrganization, owner, language, mediaType, expertise, skill);
	}
	
	@Override
    public int compareTo(CatalogueData o) {
        return this.getCreateDate().compareTo(o.getCreateDate());
    }
}
