/**
 * 
 */
package com.cts.course.data;

/**
 * @author Jayaramu Vellingiri
 *
 */
public class ColumnNameData {

	private int id;
	private String name;
	private String columnAliasName;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getColumnAliasName() {
		return columnAliasName;
	}
	public void setColumnAliasName(String columnAliasName) {
		this.columnAliasName = columnAliasName;
	}
	
}
