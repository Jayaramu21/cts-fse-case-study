/**
 * 
 */
package com.cts.course.util;

/**
 * @author jayaramu.v
 *
 */
public class PropertiesConfigUtil {
	
	public static final String driver_name = "driver_class";
	public static final String database_url ="database_url";
	public static final String user_name = "user_name";
	public static final String password = "password";
	public static final String dialect = "hibernate.dialect";
	public static final String show_sql = "hibernate.show_sql";
	public static final String query_cache = "hibernate.query_cache";
	
	public static final String generate_ddl = "generate_ddl";
	public static final String component_scan = "component_scan";
	public static final String second_level_cache = "hibernate.second_level_cache";
	public static final String factory_class = "factory_class";
	public static final String generate_statistics = "generate_statistics";
	public static final String format_sql = "format_sql";
	public static final String statement_cache_size = "statement_cache_size";
	public static final String max_idle_time = "max_idle_time";
	public static final String product_by_volume = "product_by_volume";
	
}
