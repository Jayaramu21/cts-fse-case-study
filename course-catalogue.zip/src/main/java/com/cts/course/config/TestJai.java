/**
 * 
 */
package com.cts.course.config;

/**
 * @author Jayaramu Vellingiri
 *
 */
public class TestJai {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "skill.skill";
		if(str.contains(".")) {
			System.out.println(str.split("\\.")[1]);
		}
	}

}
