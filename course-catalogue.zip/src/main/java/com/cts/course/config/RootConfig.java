/**
 * 
 */
package com.cts.course.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * @author jayaramu.v
 *
 */
@Configuration
@ComponentScan({"com.cts.course"})
public class RootConfig {

}
