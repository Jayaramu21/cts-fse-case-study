/**
 * 
 */
package com.cts.course.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.InputStreamSource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.cts.course.data.AdvanceFilterDataImport;
import com.cts.course.data.BasicFilterDataImport;
import com.cts.course.data.CatalogueData;
import com.cts.course.data.ColumnNameData;
import com.cts.course.data.CourseListExportData;
import com.cts.course.service.CatalougeServiceI;

/**
 * @author Jayaramu Vellingiri
 *
 */
@Controller
public class CatalogueController {
	
	@Autowired
	CatalougeServiceI catalougeService;

	@RequestMapping(value = "/catalogue", method = RequestMethod.GET)
	public ModelAndView courseCatalogue(ModelAndView model, HttpSession session) {
		model.setViewName("course_catalogue_details");
		return model;
	}
	
	@RequestMapping(value = "/validate", method = RequestMethod.POST)
	public ResponseEntity<?> validateExcel(@RequestParam("courseCatalog") MultipartFile courseCatalog) throws Exception {
		String validationStatus = catalougeService.validateInputExcel(courseCatalog);
		return new ResponseEntity<>(validationStatus, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/upload", method = RequestMethod.POST)
	public ResponseEntity<?> uploadDatabase(@RequestParam("courseCatalog") MultipartFile uploadFile) throws Exception {
		String status = catalougeService.readInputExcelNInsertRecord(uploadFile);
		return new ResponseEntity<>(status, HttpStatus.OK);	
	}
	
	@GetMapping(value = "/courselist", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public CourseListExportData getCourseList(@RequestParam("pageNo") Integer pageNumber, @RequestParam("limit") Integer rowLimit, ModelAndView model, HttpSession session) throws Exception {
		return catalougeService.readAllCourseCatalogue(pageNumber, rowLimit);		
	}
	
	@PostMapping(value = "/export", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<InputStreamSource> exportCourseCatalogue(@RequestBody List<CatalogueData> catalogueDataList) throws Exception {
		try {
		System.out.println(catalogueDataList.toString());
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.parseMediaType("application/vnd.ms-excel"));
		httpHeaders.add("Content-Disposition", "attachment; filename=courseCatalogue.xlsx");
		return ResponseEntity.ok().headers(httpHeaders).body(new InputStreamResource(catalougeService.downloadCatalogueDetails(catalogueDataList)));
		}catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@PostMapping(value = "/basicfilter", consumes = MediaType.APPLICATION_JSON_VALUE, produces=MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public CourseListExportData getCourseList(@RequestBody BasicFilterDataImport basicFilterDataImport) throws Exception {
		return catalougeService.readCourseCatalogueByBasicFilter(basicFilterDataImport);
	}
	
	@GetMapping(value = "/columnlist", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<ColumnNameData> getColumnList() throws Exception {
		return catalougeService.readColumnNames();		
	}
	
	@PostMapping(value = "/advancefilter", consumes = MediaType.APPLICATION_JSON_VALUE,  produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public CourseListExportData getAdvanceFilter(@RequestBody List<AdvanceFilterDataImport> advanceFilterDataImportList) throws Exception {
		System.out.println("advanceFilterDataImportList: "+ advanceFilterDataImportList.size() + " "+ advanceFilterDataImportList.get(0).toString());
		return catalougeService.readCourseCatalogueByAdvanceFilterCatalogue(advanceFilterDataImportList);		
	}
	
	
}
