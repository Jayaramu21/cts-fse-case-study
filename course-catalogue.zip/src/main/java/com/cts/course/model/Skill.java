/**
 * 
 */
package com.cts.course.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Jayaramu Vellingiri
 *
 */
@Entity
@Table(name = "course_t_skill")
public class Skill {

	private int id;
	private String skill;

	/**
	 * @return the id
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	@Column(name = "skill")
	public String getSkill() {
		return skill;
	}

	public void setSkill(String skill) {
		this.skill = skill;
	}

	/**
	 * @return the skill
	 */
	


	@Override
	public String toString() {
		return String.format("Skill [id=%s, skill=%s]", id, skill);
	}
}
