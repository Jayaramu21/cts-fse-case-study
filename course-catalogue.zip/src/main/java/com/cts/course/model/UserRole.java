/**
 * 
 */
package com.cts.course.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author jayaramu.v
 *
 */
@Entity
@Table(name = "course_t_role")
public class UserRole {

	private Integer role_id;
	private String role;
	
//	private Set<User> user;

	
	/**
	 * @return the role_id
	 */
	@Id
	@GeneratedValue
	@Column(name = "role_id")
	public Integer getRole_id() {
		return role_id;
	}

	/**
	 * @param role_id
	 *            the role_id to set
	 */
	public void setRole_id(Integer role_id) {
		this.role_id = role_id;
	}
	/**
	 * @return the role
	 */
	@Column(name = "role", nullable = false, unique = true, length = 50)
	public String getRole() {
		return role;
	}

	/**
	 * @param role
	 *            the role to set
	 */
	public void setRole(String role) {
		this.role = role;
	}
	
//	/**
//	 * @return the user
//	 */
//	@OneToMany(fetch = FetchType.LAZY, mappedBy = "helikx_t_role")
//	public Set<User> getUser() {
//		return user;
//	}
//
//	/**
//	 * @param user the user to set
//	 */
//	public void setUser(Set<User> user) {
//		this.user = user;
//	}



}
