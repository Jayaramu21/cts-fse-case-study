/**
 * 
 */
package com.cts.course.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @author Jayaramu Vellingiri
 *
 */
@Entity
@Table(name = "course_t_catalouge")
public class Catalogue {

	private int id;
	private String name;
	private String code;
	private String description;
	private String duration;
	private String prerequisites;
	private String notes;
	private Date createDate;	
	private boolean licenceInd;
	private char activeStatus;
	private Integer proficiencyLevel;
	
	private TrainingOrganization trainingOrganization;
	private Owner owner;
	private Language language;
	private MediaType mediaType;
	private Expertise expertise;
	private Skill skill;
	
	
	/**
	 * @return the id
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "id")
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	@Column(name = "name", nullable = false, unique = true)
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	@Column(name = "code", nullable = false, unique = true)
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	/**
	 * @return the description
	 */
	@Column(name = "description")
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the duration
	 */
	@Column(name = "duration")
	public String getDuration() {
		return duration;
	}
	/**
	 * @param duration the duration to set
	 */
	public void setDuration(String duration) {
		this.duration = duration;
	}
	/**
	 * @return the prerequisites
	 */
	@Column(name = "prerequisites")
	public String getPrerequisites() {
		return prerequisites;
	}
	/**
	 * @param prerequisites the prerequisites to set
	 */
	public void setPrerequisites(String prerequisites) {
		this.prerequisites = prerequisites;
	}
	/**
	 * @return the notes
	 */
	@Column(name = "notes")
	public String getNotes() {
		return notes;
	}
	/**
	 * @param notes the notes to set
	 */
	public void setNotes(String notes) {
		this.notes = notes;
	}
	/**
	 * @return the createDate
	 */
	@Column(name = "create_date")
	public Date getCreateDate() {
		return createDate;
	}
	/**
	 * @param createDate the createDate to set
	 */
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	/**
	 * @return the licenceInd
	 */
	@Column(name = "licence_ind")
	public boolean isLicenceInd() {
		return licenceInd;
	}
	/**
	 * @param licenceInd the licenceInd to set
	 */
	public void setLicenceInd(boolean licenceInd) {
		this.licenceInd = licenceInd;
	}
	/**
	 * @return the trainingOrganization
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "fk_training_organization", nullable = false)
	public TrainingOrganization getTrainingOrganization() {
		return trainingOrganization;
	}
	/**
	 * @param trainingOrganization the trainingOrganization to set
	 */
	public void setTrainingOrganization(TrainingOrganization trainingOrganization) {
		this.trainingOrganization = trainingOrganization;
	}
	/**
	 * @return the owner
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "fk_owner", nullable = false)
	public Owner getOwner() {
		return owner;
	}
	/**
	 * @param owner the owner to set
	 */
	public void setOwner(Owner owner) {
		this.owner = owner;
	}
	/**
	 * @return the language
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "fk_language", nullable = false)
	public Language getLanguage() {
		return language;
	}
	/**
	 * @param language the language to set
	 */
	public void setLanguage(Language language) {
		this.language = language;
	}
	/**
	 * @return the mediaType
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "fk_media_type", nullable = true)
	public MediaType getMediaType() {
		return mediaType;
	}
	/**
	 * @param mediaType the mediaType to set
	 */
	public void setMediaType(MediaType mediaType) {
		this.mediaType = mediaType;
	}
	/**
	 * @return the expertise
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "fk_expertise", nullable = false)
	public Expertise getExpertise() {
		return expertise;
	}
	/**
	 * @param expertise the expertise to set
	 */
	public void setExpertise(Expertise expertise) {
		this.expertise = expertise;
	}
	/**
	 * @return the skill
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "fk_skill", nullable = false)
	public Skill getSkill() {
		return skill;
	}
	/**
	 * @param skill the skill to set
	 */
	public void setSkill(Skill skill) {
		this.skill = skill;
	}
	
	@Column(name = "active_status", nullable = false)
	public char getActiveStatus() {
		return activeStatus;
	}
	public void setActiveStatus(char activeStatus) {
		this.activeStatus = activeStatus;
	}
	@Column(name = "proficiency_level", nullable = false)
	public Integer getProficiencyLevel() {
		return proficiencyLevel;
	}
	public void setProficiencyLevel(Integer proficiencyLevel) {
		this.proficiencyLevel = proficiencyLevel;
	}
}
