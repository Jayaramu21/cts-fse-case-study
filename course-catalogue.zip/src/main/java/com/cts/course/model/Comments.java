/**
 * 
 */
package com.cts.course.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Jayaramu
 *
 */
@Entity
@Table(name = "comments")
public class Comments {

	/**
	 * 
	 */
	public Comments() {
	}

	private int comment_id;
	private Integer data_id;
	private String comment;
	private String comment_by;

	/**
	 * @return the comment_id
	 */
	@Id
	@GeneratedValue
	@Column(name = "comment_id")
	public int getComment_id() {
		return comment_id;
	}

	/**
	 * @param comment_id
	 *            the comment_id to set
	 */
	public void setComment_id(int comment_id) {
		this.comment_id = comment_id;
	}

	/**
	 * @return the data_id
	 */
	@Column(name = "data_id")
	public Integer getData_id() {
		return data_id;
	}

	/**
	 * @param data_id
	 *            the data_id to set
	 */
	public void setData_id(Integer data_id) {
		this.data_id = data_id;
	}

	/**
	 * @return the comment
	 */
	@Column(name = "comment")
	public String getComment() {
		return comment;
	}

	/**
	 * @param comment
	 *            the comment to set
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}

	/**
	 * @return the comment_by
	 */
	@Column(name = "comment_by")
	public String getComment_by() {
		return comment_by;
	}

	/**
	 * @param comment_by
	 *            the comment_by to set
	 */
	public void setComment_by(String comment_by) {
		this.comment_by = comment_by;
	}

}
