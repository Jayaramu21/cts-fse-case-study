/**
 * 
 */
package com.cts.course.dao;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cts.course.data.AdvanceFilterDataImport;
import com.cts.course.data.BasicFilterDataImport;
import com.cts.course.model.Catalogue;
import com.cts.course.model.ColumnName;
import com.cts.course.model.Expertise;
import com.cts.course.model.Language;
import com.cts.course.model.MediaType;
import com.cts.course.model.Owner;
import com.cts.course.model.Skill;
import com.cts.course.model.TrainingOrganization;

/**
 * @author Jayaramu Vellingiri
 *
 */
@SuppressWarnings("unchecked")
@Repository("courseCatalogueDAO")
public class CourseCatalogueDAO implements CourseCatalogueDAOI {

	@Autowired
	SessionFactory sessionFactory;

	@Override
	public List<Catalogue> getCatalougeList(Integer pageNumber, Integer offSet, Integer rowLimit) throws Exception {
		Session catalogueSession = sessionFactory.getCurrentSession();
		Criteria catalogueCriteria = catalogueSession.createCriteria(Catalogue.class);
		catalogueCriteria.add(Restrictions.eq("activeStatus", 'A'));
		catalogueCriteria.addOrder(Order.asc("createDate"));
//		catalogueCriteriaOffset.setFirstResult(offSet);
//		catalogueCriteriaOffset.setMaxResults(rowLimit);
		return catalogueCriteria.list();
	}

	@Override
	public List<Language> getLanguageList() throws Exception {
		return sessionFactory.getCurrentSession().createCriteria(Language.class).list();
	}

	@Override
	public List<MediaType> getMediaTypeList() throws Exception {
		return sessionFactory.getCurrentSession().createCriteria(MediaType.class).list();
	}

	@Override
	public List<Owner> getOwnerList() throws Exception {
		return sessionFactory.getCurrentSession().createCriteria(Owner.class).list();
	}

	@Override
	public List<Skill> getSkillList() throws Exception {
		return sessionFactory.getCurrentSession().createCriteria(Skill.class).list();
	}

	@Override
	public List<Expertise> geExpertiseList() throws Exception {
		return sessionFactory.getCurrentSession().createCriteria(Expertise.class).list();
	}

	@Override
	public List<TrainingOrganization> getTrainingOrganizationList() throws Exception {
		return sessionFactory.getCurrentSession().createCriteria(TrainingOrganization.class).list();
	}

	@Override
	public void saveLanuage(Language language) throws Exception {
		Session session = sessionFactory.getCurrentSession();
		session.save(language);
		session.flush();
	}

	@Override
	public void saveMediaType(MediaType mediaType) throws Exception {
		Session session = sessionFactory.getCurrentSession();
		session.save(mediaType);
		session.flush();
	}

	@Override
	public void saveOwner(Owner owner) throws Exception {
		Session session = sessionFactory.getCurrentSession();
		session.save(owner);
		session.flush();
	}

	@Override
	public void saveSkill(Skill skill) throws Exception {
		Session session = sessionFactory.getCurrentSession();
		session.save(skill);
		session.flush();
	}

	@Override
	public void saveTrainingOrg(TrainingOrganization trainingOrganization) throws Exception {
		Session session = sessionFactory.getCurrentSession();
		session.save(trainingOrganization);
		session.flush();
	}

	@Override
	public void saveCourseCatalogue(List<Catalogue> catalogueList) throws Exception {
		Session session = sessionFactory.getCurrentSession();
		int count = 0;
		for (Catalogue catalogue : catalogueList) {
			session.save(catalogue);
			if (++count % 20 == 0) {
				session.flush();
				session.clear();
				count = 0;
			}
		}
		if (count > 0) {
			session.flush();
			session.clear();
		}
	}

//	@Override
//	public List<Catalogue> getCatalogueByBasicFilter(BasicFilterDataImport basicImport) throws Exception {
//
//		String courseName = basicImport.getCourseName();
//		String skill = basicImport.getSkill();
//		Integer proficiencyLevel = basicImport.getProficiencyLevel();
//		String courseOperator = basicImport.getCourseNameOperator();
//		String skillOperator = basicImport.getSkillOperator();
//		String proficiencyLevelOperator = basicImport.getProficiencyLevelOperator();
//
//		Session session = sessionFactory.getCurrentSession();
//		DetachedCriteria criteria = DetachedCriteria.forClass(Catalogue.class);
//		if (StringUtils.isNotBlank(courseName)) {
//			Criterion courseCriterion = courseOperator.equals("eq") ? Restrictions.eq("name", courseName)
//					: courseOperator.equals("ne") ? Restrictions.ne("name", courseName)
//							: courseOperator.equals("contains")
//									? Restrictions.like("name", courseName, MatchMode.ANYWHERE)
//									: null;
//			criteria.add(courseCriterion);
//		}
//
//		if (StringUtils.isNotBlank(skill)) {
//			Criterion skillCriterion = skillOperator.equals("eq") ? Restrictions.eq("skill.skill", skill)
//					: skillOperator.equals("ne") ? Restrictions.ne("skill.skill", skill)
//							: skillOperator.equals("contains") ? Restrictions.like("skill.skill", skill) : null;
//			criteria.add(skillCriterion);
//		}
//
//		if (proficiencyLevel != null) {
//			Criterion proficiencyLevelCriterion = proficiencyLevelOperator.equals("eq")
//					? Restrictions.eq("proficiencyLevel", proficiencyLevel)
//					: proficiencyLevelOperator.equals("ne") ? Restrictions.ne("proficiencyLevel", proficiencyLevel)
//							: proficiencyLevelOperator.equals("grt")
//									? Restrictions.gt("proficiencyLevel", proficiencyLevel)
//									: proficiencyLevelOperator.equals("lst")
//											? Restrictions.lt("proficiencyLevel", proficiencyLevel)
//											: null;
//			criteria.add(proficiencyLevelCriterion);
//		}
//		return criteria.getExecutableCriteria(session).list();
//	}
	
	
	@Override
	public List<Catalogue> getCatalogueByBasicFilter(BasicFilterDataImport basicImport) throws Exception {

		String courseName = basicImport.getCourseName();
		String skill = basicImport.getSkill();
		Integer proficiencyLevel = basicImport.getProficiencyLevel();
		String courseOperator = basicImport.getCourseNameOperator();
		String skillOperator = basicImport.getSkillOperator();
		String proficiencyLevelOperator = basicImport.getProficiencyLevelOperator();

		Session session = sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Catalogue.class, "catalog");
		if (StringUtils.isNotBlank(courseName)) {
			Criterion courseCriterion = courseOperator.equals("eq") ? Restrictions.eq("name", courseName)
					: courseOperator.equals("ne") ? Restrictions.ne("name", courseName)
							: courseOperator.equals("contains")
									? Restrictions.like("name", courseName, MatchMode.ANYWHERE)
									: null;
			criteria.add(courseCriterion);
		}

		if (StringUtils.isNotBlank(skill)) {
			criteria.createAlias("catalog.skill", "skill");
			Criterion skillCriterion = skillOperator.equals("eq") ? Restrictions.eq("skill.skill", skill)
					: skillOperator.equals("ne") ? Restrictions.ne("skill.skill", skill)
							: skillOperator.equals("contains") ? Restrictions.like("skill.skill", skill, MatchMode.ANYWHERE) : null;
			criteria.add(skillCriterion);
		}

		if (proficiencyLevel != null) {
			Criterion proficiencyLevelCriterion = proficiencyLevelOperator.equals("eq")
					? Restrictions.eq("proficiencyLevel", proficiencyLevel)
					: proficiencyLevelOperator.equals("ne") ? Restrictions.ne("proficiencyLevel", proficiencyLevel)
							: proficiencyLevelOperator.equals("grt")
									? Restrictions.gt("proficiencyLevel", proficiencyLevel)
									: proficiencyLevelOperator.equals("lst")
											? Restrictions.lt("proficiencyLevel", proficiencyLevel)
											: null;
			criteria.add(proficiencyLevelCriterion);
		}
		return criteria.list();
	}

	@Override
	public List<Catalogue> getCatalogueByAdvanceFilter(List<AdvanceFilterDataImport> advanceImport) throws Exception {
		Session session = sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Catalogue.class, "catalog");

		for (AdvanceFilterDataImport conditionClass : advanceImport) {
			String operator = conditionClass.getOperator().trim();
			String columnName = conditionClass.getColumnName().trim();
			String value = conditionClass.getValue().trim();
			if (columnName.equalsIgnoreCase("proficiencyLevel")) {
				Criterion proficiencyLevelCriterion = operator.equals("eq")
						? Restrictions.eq(columnName, Integer.valueOf(value))
						: operator.equals("ne") ? Restrictions.ne(columnName, Integer.valueOf(value))
								: operator.equals("grt") ? Restrictions.gt(columnName, Integer.valueOf(value))
										: operator.equals("lst") ? Restrictions.lt(columnName, Integer.valueOf(value))
												: null;
				criteria.add(proficiencyLevelCriterion);
			} else {
				if(columnName.contains(".")) {
					criteria.createAlias("catalog."+columnName.split("\\.")[0], columnName.split("\\.")[0]);
				}
				Criterion proficiencyLevelCriterion = operator.equals("eq") ? Restrictions.eq(columnName, value)
						: operator.equals("ne") ? Restrictions.ne(columnName, value)
								: operator.equals("grt") ? Restrictions.gt(columnName, value)
										: operator.equals("lst") ? Restrictions.lt(columnName, value)
												: operator.equals("contains")
														? Restrictions.like(columnName, value, MatchMode.ANYWHERE)
														: null;
				criteria.add(proficiencyLevelCriterion);
			}
		}
		return criteria.list();
	}

	@Override
	public List<ColumnName> getColumnName() throws Exception {
		return sessionFactory.getCurrentSession().createCriteria(ColumnName.class).list();
	}

	@Override
	public void saveExpertise(Expertise expertise) throws Exception {
		Session session = sessionFactory.getCurrentSession();
		session.save(expertise);
		session.flush();

	}
}
