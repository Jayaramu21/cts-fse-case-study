/**
 * 
 */
package com.cts.course.dao;

import java.util.List;

import com.cts.course.data.AdvanceFilterDataImport;
import com.cts.course.data.BasicFilterDataImport;
import com.cts.course.model.Catalogue;
import com.cts.course.model.ColumnName;
import com.cts.course.model.Expertise;
import com.cts.course.model.Language;
import com.cts.course.model.MediaType;
import com.cts.course.model.Owner;
import com.cts.course.model.Skill;
import com.cts.course.model.TrainingOrganization;

/**
 * @author Jayaramu Vellingiri
 *
 */
public interface CourseCatalogueDAOI {
	
	public List<Catalogue> getCatalougeList(Integer pageNumber, Integer offSet, Integer rowLimit) throws Exception;
	
	public List<Language> getLanguageList() throws Exception;
	
	public List<MediaType> getMediaTypeList() throws Exception;
	
	public List<Owner> getOwnerList() throws Exception;
	
	public List<Skill> getSkillList() throws Exception;
	
	public List<Expertise> geExpertiseList() throws Exception;
	
	public List<TrainingOrganization> getTrainingOrganizationList() throws Exception;
	
	public void saveLanuage(Language language) throws Exception;
	
	public void saveMediaType(MediaType mediaType) throws Exception;
	
	public void saveExpertise(Expertise expertise) throws Exception;
	
	public void saveOwner(Owner owner) throws Exception;
	
	public void saveSkill(Skill skill) throws Exception;
	
	public void saveTrainingOrg(TrainingOrganization trainingOrganization) throws Exception;
	
	public void saveCourseCatalogue(List<Catalogue> catalogueList) throws Exception;
	 
	public List<Catalogue> getCatalogueByBasicFilter(BasicFilterDataImport basicImport) throws Exception;
	
	public List<Catalogue> getCatalogueByAdvanceFilter(List<AdvanceFilterDataImport> advanceImport) throws Exception;
	
	public List<ColumnName> getColumnName() throws Exception;
}
