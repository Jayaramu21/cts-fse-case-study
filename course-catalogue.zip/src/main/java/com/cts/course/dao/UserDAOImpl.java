/**
 * 
 */
package com.cts.course.dao;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cts.course.model.User;

/**
 * @author jayaramu.v
 *
 */
@Repository
public class UserDAOImpl implements UserDAOI {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public User fetchUserDetails(String userName) {

		User userDetails = null;
		Session userSession = null;
		try {
			userSession = sessionFactory.getCurrentSession();
			Criteria criteria = userSession
					.createCriteria(User.class);
			criteria.add(Restrictions.or(Restrictions.eq("name", userName)));
			userDetails = (User) criteria.uniqueResult();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return userDetails;

	}

	@Override
	public User readUserDetails() {

		Session userSession = sessionFactory.getCurrentSession();
		Criteria criteria = userSession.createCriteria(User.class);
		Criterion criterion = Restrictions.and(Restrictions.eq("id", 1));
		criteria.add(criterion);
		return null;
	}

}
