/**
 * 
 */
package com.cts.course.dao;

import com.cts.course.model.User;

/**
 * @author jayaramu.v
 *
 */
public interface UserDAOI {

	public User fetchUserDetails(String userName);
	public User readUserDetails();
	
}
