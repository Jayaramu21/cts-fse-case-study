/**
 * 
 */
package com.cts.course.globals;

/**
 * @author Jayaramu Vellingiri
 *
 */
public enum ExcelColumnHeaderEnum {

	COURSENAME("Course Name"), DESCRIPTION("Description"), DURATION("Duration"),
	ACTIVITYSTATUS("Activity Status"), CODE("Code"), TRAININGORGANIZATION("Training Organization"),
	OWNER("Owner"), LANGUAGE("Language"), MEDIATYPE("Media Type"), EXPERTISE("Expertise"),
	PREREQUISITES("Prerequisites"), LICENCENEED("Licence Need"), NOTES("Notes"), SKILL("Skill"), PROFICIENCY("Proficiency");
	
	private String headerName;
	
	ExcelColumnHeaderEnum(String headerName){
		this.headerName = headerName;
	}

	public String getHeaderName() {
		return headerName;
	}

	public void setHeaderName(String headerName) {
		this.headerName = headerName;
	}
	
}
