/**
 * 
 */
package com.cts.course.globals;

/**
 * @author Jayaramu Vellingiri
 *
 */
public class CustomeExceptionHandler extends Exception {

	private static final long serialVersionUID = 8155248917671183483L;
	
	String exceptionMessage;
	
	public CustomeExceptionHandler(String exceptionMessage) {
		this.exceptionMessage = exceptionMessage;
	}
	
	@Override
	public String toString() {
		return (exceptionMessage);
	}
	
}
