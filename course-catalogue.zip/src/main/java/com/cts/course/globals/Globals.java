/**
 * 
 */
package com.cts.course.globals;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.YearMonth;
import java.time.ZoneId;
import java.util.Date;

/**
 * @author jayaramu.v
 *
 */
public class Globals {

	static SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	public static void main(String abc[]) {

		String todayEndDate = formatter.format(getEndOfDay(new Date())
				.getTime());
		String todayStartDate = formatter.format(getStartOfDay(new Date())
				.getTime());

		System.out.println("todayEndDate: " + todayEndDate);
		System.out.println("todayStartDate: " + todayStartDate);

	}

	public static Date getEndOfDay(Date date) {
		LocalDateTime localDateTime = dateToLocalDateTime(date);
		LocalDateTime endOfDay = localDateTime.with(LocalTime.MAX);
		return localDateTimeToDate(endOfDay);
	}

	public static Date getStartOfDay(Date date) {
		LocalDateTime localDateTime = dateToLocalDateTime(date);
		LocalDateTime startOfDay = localDateTime.with(LocalTime.MIN);
		return localDateTimeToDate(startOfDay);
	}

	private static Date localDateTimeToDate(LocalDateTime startOfDay) {
		return Date.from(startOfDay.atZone(ZoneId.systemDefault()).toInstant());
	}

	private static LocalDateTime dateToLocalDateTime(Date date) {
		return LocalDateTime.ofInstant(Instant.ofEpochMilli(date.getTime()),
				ZoneId.systemDefault());
	}

	public static java.sql.Timestamp readMonthStartTimeStamp(YearMonth yearMonth) {

		java.sql.Timestamp timeStampMonthStartDate = null;

		try {
			LocalDate firstOfMonth = yearMonth.atDay(1);
			Date monthStartDate = Date.from(firstOfMonth.atStartOfDay(
					ZoneId.systemDefault()).toInstant());
			String monthStartDateStr = formatter.format(monthStartDate
					.getTime());
			monthStartDate = formatter.parse(monthStartDateStr);
			timeStampMonthStartDate = new Timestamp(monthStartDate.getTime());
		} catch (ParseException parE) {
			parE.printStackTrace();
		}
		return timeStampMonthStartDate;
	}

	public static java.sql.Timestamp readMonthEndTimeStamp(YearMonth yearMonth) {
		java.sql.Timestamp timeStampMonthEndDate = null;
		try {
			LocalDate last = yearMonth.atEndOfMonth();
			Date monthEndDate = Date.from(last
					.atStartOfDay(ZoneId.systemDefault()).plusDays(1)
					.minusSeconds(1).toInstant());
			String monthEndDateStr = formatter.format(monthEndDate.getTime());
			monthEndDate = formatter.parse(monthEndDateStr);
			timeStampMonthEndDate = new Timestamp(monthEndDate.getTime());
		} catch (ParseException parE) {
			parE.printStackTrace();
		}
		return timeStampMonthEndDate;
	}
	
	public static double round(double value, int places) {
	    if (places < 0) throw new IllegalArgumentException();

	    BigDecimal bd = new BigDecimal(value);
	    bd = bd.setScale(places, RoundingMode.HALF_UP);
	    return bd.doubleValue();
	}

}
