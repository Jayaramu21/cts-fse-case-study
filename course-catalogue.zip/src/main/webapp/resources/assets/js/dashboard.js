(function($) {
  'use strict';
  $(function() {
    loadDatatable();
  });
})(jQuery);


function loadDatatable(){

    function format ( d ) {
      // `d` is the original data object for the row
      return '<table cellpadding="5" cellspacing="0" border="0" style="width:100%;">'+
          '<tr class="expanded-row">'+
              '<td colspan="8" class="row-bg"><div><div class="d-flex justify-content-between"><div class="cell-hilighted"><div class="d-flex mb-2"><div class="mr-2 min-width-cell"><p>Description</p><h6>'+d.description+'</h6></div></div><div class="d-flex"><div class="mr-2 min-width-cell"><p>Notes</p><h6>'+d.notes+'</h6></div></div></div></div></td>'
          '</tr>'+
      '</table>';
  }
  var table = $('#example').DataTable( {
	  "ajax": {
          "url": "courselist?pageNo=1&limit=10",
          "dataSrc": "data"
      },
    "columns": [
        { "data": "code" },
        { "data": "name" },
        { "data": "skill.skill" },
        { "data": "duration" }, 
        { "data": "licenceInd" }, 
        { "data": "proficiencyLevel" }, 
        { "data": "trainingOrganization.organization" }, 
        {
          "className":      'details-control',
          "orderable":      false,
          "data":           null,
          "defaultContent": ''
        }
    ],
    "order": [[1, 'asc']],
    "paging":   true,
    "ordering": true,
    "info":     true,
    "filter": true,
    "bDestroy": true,
    columnDefs: [{
      orderable: false,
      className: 'select-checkbox',
      targets: 0
    }],
    select: {
      style: 'os',
      selector: 'td:first-child'
    }
  } );

$( '#basicFilter' )
.click( function( e ) {
	
	 $.ajax( {   	
		    url: 'basicfilter',
		    type: 'POST',
		    dataType: 'json',
		    headers: { 
		        'Content-Type': 'application/json' 
		    },
		    data: JSON.stringify(Object.fromEntries(new FormData(document.getElementById("basicFilterForm")))),
		    processData: false,
		    contentType: false,
		    success: function(data){		    	
		     data = JSON.parse(JSON.stringify(data.data));
		     var table = $('#example').DataTable( {
		        data: data,
		        columns: [
		            { data: "code" },
		            { data: "name" },
		            { data: "skill.skill" },
		            { data: "duration" }, 
		            { data: "licenceInd" }, 
		            { data: "proficiencyLevel" }, 
		            { data: "trainingOrganization.organization" }, 
		            {
		              "className":      'details-control',
		              "orderable":      false,
		              "data":           null,
		              "defaultContent": ''
		            }
		        ],
		        "order": [[1, 'asc']],
		        "paging":   true,
		        "ordering": true,
		        "info":     true,
		        "filter": true,
		        "bDestroy": true,
		        columnDefs: [{
		          orderable: false,
		          className: 'select-checkbox',
		          targets: 0
		        }],
		        select: {
		          style: 'os',
		          selector: 'td:first-child'
		        }
		      });		    	
		  },
		  error: function (textStatus, errorThrown) {
		  	alert("Status " + textStatus);
		  }
		  });
});

$('#example tbody').on('click', 'td.details-control', function () {
	  var tr = $(this).closest('tr');
	  var table = $('#example').DataTable();
	  var row = table.row( tr );

	  if ( row.child.isShown() ) {
	      // This row is already open - close it
	      row.child.hide();
	      tr.removeClass('shown');
	  }
	  else {
	      // Open this row
	      row.child( format(row.data()) ).show();
	      tr.addClass('shown');
	  }
	} );

$('#exportExcel').click(function() {
    var tableObjects = [];
    var t = document.getElementById('tBody');
    var table = $('#example').DataTable();
    
    $('table#example > tbody  > tr').each(function(index, tr) { 
    	var row = table.row( tr );
    	var data = row.data();
    	tableObjects.push({
            code: data.code,
            name: data.name,
            description: data.description,
            skill: {skill : data.skill.skill},
            duration: data.duration,
            licenceInd: data.licenceInd,
            proficiencyLevel: data.proficiencyLevel,
            trainingOrganization: {organization: data.trainingOrganization.organization},
            prerequisites: data.prerequisites,
            notes: data.notes,
            language: {language : data.language.language}
        })
    	});
    $.ajax({
        url: 'export',
        method: 'POST',
        contentType : 'application/json; charset=utf-8',
        xhrFields:{
            responseType: 'blob'
        },
       data: JSON.stringify(tableObjects),
    success : function(data) {
    	console.log(data)
    	 var blob = data;
         var downloadUrl = URL.createObjectURL(blob);
         var a = document.createElement("a");
         a.href = downloadUrl;
         a.download = "courseCatalogue.xlsx";
         document.body.appendChild(a);
         a.click();
    },
    error: function (textStatus, errorThrown) {
		  	var blob = textStatus.responseText;
		  	var binaryData = [];
		  	binaryData.push(blob);
		  	var downloadUrl = window.URL.createObjectURL(new Blob(binaryData, {type: "application/vnd.ms-excel"}))
		  	console.log(blob);
//	         var downloadUrl = URL.createObjectURL(blob);
	         var a = document.createElement("a");
	         a.href = downloadUrl;
	         a.download = "courseCatalogue.xlsx";
	         document.body.appendChild(a);
	         a.click();
		  }
    });
    });
    

$('#advanceFilterBtn').click(function() {
    var advTableObjects = [];
    var t = document.getElementById('advFilterBody');
    var table = $('#advanceFilterTable').DataTable();
    
    $('table#advanceFilterTable > tbody  > tr').each(function(index, tr) { 
    	var row = table.row( tr );
    	var data = row.data();
    	 var condition = $(this).find('select[name="advCondition"]').val();
         var column = $(this).find('select[name="advColumn"]').val();
         var value = $(this).find('input[name="advFilterValue"]').val();
   
         advTableObjects.push({
    		columnName: column,
    		operator: condition,
    		value: value,
        })
    	});
    $.ajax({
        url: 'advancefilter',
        method: 'POST',
        dataType: 'json',
	    headers: { 
	        'Content-Type': 'application/json' 
	    },
        data: JSON.stringify(advTableObjects)
    })
    .done(function(data) {
        console.log(data);
        data = JSON.parse(JSON.stringify(data.data));
	     var table = $('#example').DataTable( {
	        data: data,
	        columns: [
	            { data: "code" },
	            { data: "name" },
	            { data: "skill.skill" },
	            { data: "duration" }, 
	            { data: "licenceInd" }, 
	            { data: "proficiencyLevel" }, 
	            { data: "trainingOrganization.organization" }, 
	            {
	              "className":      'details-control',
	              "orderable":      false,
	              "data":           null,
	              "defaultContent": ''
	            }
	        ],
	        "order": [[1, 'asc']],
	        "paging":   true,
	        "ordering": true,
	        "info":     true,
	        "filter": true,
	        "bDestroy": true,
	        columnDefs: [{
	          orderable: false,
	          className: 'select-checkbox',
	          targets: 0
	        }],
	        select: {
	          style: 'os',
	          selector: 'td:first-child'
	        }
	      });		    	
    })
    .fail(function() {
    });
});

}

