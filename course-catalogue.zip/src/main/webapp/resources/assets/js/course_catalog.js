$(document).ready(function () {
	var advanceFilterTable = $("#advanceFilterTable").DataTable({
	    "deferRender": true,
	    "paging": true,
	    "lengthChange": false,
	    "searching": false,
	    "ordering": false,
	    "info": true,
	    "autoWidth": false,
	    "sDom": 'lfrtip'
	});
$( '#addAdvFilterRow' )
  .click( function( e ) {	
	$.ajax({
	    type: "GET",
	    url: "columnlist",
	    contentType: "application/json; charset=utf-8",
	    dataType: "json",
	    success: function (response) {
	        var jsonObject = JSON.parse(JSON.stringify(response));	
	        var condition= '<select name="advCondition"><option value="eq">Equals</option><option value="ne">Not Eq</option><option value="contains">Contains</option><option value="grt">Greater</option><option value="lst">Less</option></select>';
	        var columnNames = '<select name="advColumn">';
	        var input = '<input name="advFilterValue" type="text"/>';
	        var removeBtn = '<button name="removeAdvFilter" type="button" class="btn btn-primary btn-sm" >X</button>';
	        $.each( jsonObject, function( key, value ) {
	        	columnNames = columnNames + '<option value="'+value.name+'">'+value.columnAliasName+'</option>';
	        });
	        var result = [];
	        columnNames = columnNames+'</select>';
	        result.push(columnNames);
	        result.push(condition);
            result.push(input);
            result.push(removeBtn);
	        advanceFilterTable.row.add(result);
	        advanceFilterTable.draw();
	    },
	    failure: function () {
	        $("#tblItems").append(" Error when fetching data please contact administrator");
	    }
	});
  } );

$('#advanceFilterTable tbody').on( 'click', 'button[name="removeAdvFilter"]', function () {
	table = $("#advanceFilterTable").DataTable();
    table
        .row( $(this).parents('tr') )
        .remove()
        .draw();
} );

});




$( '#verifyBtn' )
  .click( function( e ) {
    $.ajax( {    	
      url: 'validate',
      type: 'POST',
      data: new FormData(document.getElementById("uploadForm")),
      processData: false,
      contentType: false,
      success: function(data){
    	  swal({
    	        text: data,
    	        button: {
    	          text: "OK",
    	          value: true,
    	          visible: true,
    	          className: "btn btn-primary"
    	        }
    	      });
    },
    error: function (textStatus, errorThrown) {
    	 swal({
 	        text: textStatus,
 	        button: {
 	          text: "OK",
 	          value: true,
 	          visible: true,
 	          className: "btn btn-primary"
 	        }
 	      });
    }
    } );
    e.preventDefault();
  } );

$( '#saveCourseBtn' )
.click( function( e ) {
  $.ajax( {    	
    url: 'upload',
    type: 'POST',
    data: new FormData(document.getElementById("uploadForm")),
    processData: false,
    contentType: false,
    success: function(data){        
    	 swal({
 	        text: 'Saved Successfully',
 	        button: {
 	          text: "OK",
 	          value: true,
 	          visible: true,
 	          className: "btn btn-primary"
 	        }
 	      })
  },
  error: function (textStatus, errorThrown) {
  	alert("Status " + textStatus);
  }
  } );
  e.preventDefault();
} );










