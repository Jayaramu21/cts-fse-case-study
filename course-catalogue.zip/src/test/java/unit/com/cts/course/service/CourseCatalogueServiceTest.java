/**
 * 
 */
package unit.com.cts.course.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cts.course.dao.CourseCatalogueDAO;
import com.cts.course.data.ColumnNameData;
import com.cts.course.data.CourseListExportData;
import com.cts.course.model.Catalogue;
import com.cts.course.model.ColumnName;
import com.cts.course.model.Expertise;
import com.cts.course.model.Language;
import com.cts.course.model.MediaType;
import com.cts.course.model.Owner;
import com.cts.course.model.Skill;
import com.cts.course.model.TrainingOrganization;
import com.cts.course.service.impl.CatalougeService;

/**
 * @author Jayaramu Vellingiri
 *
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("Test Course Catalogue Service")
public class CourseCatalogueServiceTest {
	
	@InjectMocks
	private CatalougeService catalougeService;
	
	@Mock
	private CourseCatalogueDAO courseCatalogueDAOI;
	
	@BeforeAll
	public static void setup() {		
	}
	
	@Test
	public void test_getColumnNameList() throws Exception {
		List<ColumnName> columnNameList = new ArrayList<ColumnName>();
		ColumnName columnName = new ColumnName();
		columnName.setId(1);
		columnName.setName("JAVA");
		columnNameList.add(columnName);
		
		Mockito.when(courseCatalogueDAOI.getColumnName()).thenReturn(columnNameList);
		List<ColumnNameData> columnNameDataList = catalougeService.readColumnNames();
		assertEquals("JAVA", columnNameDataList.get(0).getName());
	}

	@Test
	public void test_getCourseCatalogList() throws Exception {
		
		TrainingOrganization trainingOrganization = new TrainingOrganization();
		Owner owner = new Owner();
		Language language = new Language();
		MediaType mediaType = new MediaType();
		Expertise expertise = new Expertise();
		Skill skill = new Skill();
				
		List<Catalogue> catalogueList = new ArrayList<Catalogue>();
		Catalogue catalogue = new Catalogue();
		catalogue.setId(1);
		catalogue.setActiveStatus('Y');
		catalogue.setCode("C1234");
		catalogue.setName("JAVA Spring MVC");
		
		catalogue.setCreateDate(new Date(new java.util.Date().getTime()));
		catalogue.setDuration("10 Days");
		catalogue.setLicenceInd(true);
		catalogue.setNotes("Junit test case");
		catalogue.setPrerequisites("Java software need");
		catalogue.setProficiencyLevel(2);
		catalogue.setDescription("Course to certify spring mvc");
		
		trainingOrganization.setOrganization("Cognizant");
		owner.setOwner("System Admin");
		language.setLanguage("English US");
		mediaType.setType("Study");
		expertise.setExpertise("Basic Java development knowledge");
		skill.setSkill("Spring MVC");
		
		catalogue.setTrainingOrganization(trainingOrganization);
		catalogue.setOwner(owner);
		catalogue.setLanguage(language);
		catalogue.setMediaType(mediaType);
		catalogue.setExpertise(expertise);
		catalogue.setSkill(skill);
		catalogueList.add(catalogue);
		
		Mockito.when(courseCatalogueDAOI.getCatalougeList(1, 0, 10)).thenReturn(catalogueList);
		CourseListExportData courseListExportData = catalougeService.readAllCourseCatalogue(1, 10);
		assertTrue(courseListExportData.getData().size() > 0);
	}
	
	

}
